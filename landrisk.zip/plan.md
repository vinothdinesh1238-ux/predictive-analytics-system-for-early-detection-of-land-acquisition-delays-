# LandRisk implementation plan

## Product
LandRisk is a responsive, client-side analytics workspace for college project demonstrations. It turns land acquisition records into explainable delay-risk decisions, with local persistence so edits immediately recalculate the entire experience.

## Implementation
- **Runtime:** dependency-light Node HTTP server on port 3000 serving a static single-page application.
- **Frontend:** semantic HTML, CSS, and vanilla JavaScript modules kept in readable project files.
- **Data:** browser `localStorage` with a versioned seed dataset containing the required LA001, LA002, and LA003 examples. A reset control restores the demonstration dataset.
- **Risk engine:** deterministic weighted scoring across ownership, payment, documentation, weather, market, logistics, and previous delay history. Scores are clamped to 0–100 and classified as Low (0–39), Medium (40–69), or High (70–100). Each record also derives delay range, primary reason, warning copy, and recommended action.
- **Navigation:** route-aware client-side sections for `/`, `/registry`, and `/reports`, reflected in `public/manus-routes.json`.
- **Charts:** lightweight CSS/SVG chart rendering keeps the app dependency-free and makes report views recalculate from current records.

## Design direction
- **Design movement:** editorial operations dashboard with an agritech field-notes influence.
- **Core principles:** calm authority, clear hierarchy, evidence before decoration, and action-oriented density.
- **Color philosophy:** ink navy for trust and legibility, warm parchment for the working canvas, teal for the product signal, amber for attention, and coral for high-risk urgency.
- **Layout paradigm:** a fixed command rail paired with a wide, layered workspace; metrics sit above decision panels, while tables and reports remain visually grounded in cards.
- **Signature elements:** a vertical signal rail on the brand mark, risk chips with a small status dot, and a slim workflow spine connecting the system stages.
- **Interaction philosophy:** every action should reveal its consequence; changing a record updates scores, warnings, metrics, and charts without page reloads.
- **Animation:** short 160–240ms easing for nav changes, modal entry, bars, and cards; no looping animation except a subtle live pulse on the status indicator.
- **Typography system:** Plus Jakarta Sans for UI text, with Fraunces for high-level display moments. Strong numeric hierarchy and compact uppercase metadata.
- **Brand essence:** “A field-ready early warning layer for land acquisition teams.” Personality: precise, grounded, proactive.
- **Brand voice:** headlines are direct and operational; helper text explains the next move. Examples: “Turn parcel signals into action.” and “Resolve the constraint before it becomes a delay.”
- **Wordmark & logo:** a compact `LP` monogram inside a split signal tile, followed by the LandRisk wordmark.
- **Signature brand color:** deep teal `#0f766e`, used as the ownable action and insight color.

## Project structure
- `index.html` — app shell, navigation, overview, registry, reports, modal.
- `styles.css` — responsive visual system, layout, charts, tables, modal, and mobile adaptations.
- `app.js` — state store, risk engine, rendering, interactions, local persistence, and route syncing.
- `server.js` — static file server with SPA fallback and route-manifest support.
- `public/manus-routes.json` — declared page routes for preview and publishing.
- `app.config.ts` — project logo metadata.
- `TODO.md` — outcome-level acceptance clauses from the source brief.
