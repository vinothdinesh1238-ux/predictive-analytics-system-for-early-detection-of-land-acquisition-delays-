const http = require("http");
const fs = require("fs");
const path = require("path");

const root = __dirname;
const port = Number(process.env.PORT || 3000);
const mime = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".png": "image/png" };

const server = http.createServer((req, res) => {
  const requestPath = decodeURIComponent((req.url || "/").split("?")[0]);
  const safePath = requestPath === "/" ? "/index.html" : requestPath === "/manus-routes.json" ? "/public/manus-routes.json" : requestPath;
  const filePath = path.join(root, safePath);
  const isSafe = filePath.startsWith(root) && !safePath.includes("..") && !safePath.startsWith("/api/");
  const target = isSafe && fs.existsSync(filePath) && fs.statSync(filePath).isFile() ? filePath : path.join(root, "index.html");
  const extension = path.extname(target);
  res.setHeader("Content-Type", mime[extension] || "text/plain; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache");
  fs.createReadStream(target).on("error", () => { res.statusCode = 500; res.end("Server error"); }).pipe(res);
});

server.listen(port, "0.0.0.0", () => console.log(`LandRisk listening on 0.0.0.0:${port}`));
