const STORAGE_KEY = "landrisk-parcels-v1";

const seedParcels = [
  { landId: "LA001", farmerName: "Ravi", location: "Madurai", area: 4.8, crop: "Paddy", cost: 1850000, ownership: "Disputed", payment: "Pending", documentation: "Under Review", weather: "Unfavorable", market: "Volatile", logistics: "At Risk", previousDelay: "Frequent", status: "Pending", notes: "Boundary ownership needs resolution before payment release.", month: 5 },
  { landId: "LA002", farmerName: "Kumar", location: "Dindigul", area: 3.2, crop: "Tomato", cost: 1260000, ownership: "Clear", payment: "Partial", documentation: "Incomplete", weather: "Normal", market: "Rising", logistics: "Blocked", previousDelay: "Occasional", status: "On Hold", notes: "Awaiting one missing family consent document.", month: 4 },
  { landId: "LA003", farmerName: "Priya", location: "Theni", area: 2.6, crop: "Grapes", cost: 980000, ownership: "Clear", payment: "Completed", documentation: "Under Review", weather: "Normal", market: "Rising", logistics: "At Risk", previousDelay: "None", status: "In Progress", notes: "Routine processing; monitor transport schedule.", month: 3 },
  { landId: "LA004", farmerName: "Selvam", location: "Sivaganga", area: 6.1, crop: "Cotton", cost: 2100000, ownership: "Clear", payment: "Completed", documentation: "Complete", weather: "Favorable", market: "Stable", logistics: "On Track", previousDelay: "None", status: "Completed", notes: "Acquisition closed.", month: 2 },
  { landId: "LA005", farmerName: "Meena", location: "Madurai", area: 1.9, crop: "Banana", cost: 740000, ownership: "Pending Verification", payment: "Pending", documentation: "Incomplete", weather: "Normal", market: "Stable", logistics: "At Risk", previousDelay: "Occasional", status: "On Hold", notes: "Payment and identity documents need review.", month: 5 },
  { landId: "LA006", farmerName: "Arun", location: "Theni", area: 5.4, crop: "Cardamom", cost: 2650000, ownership: "Clear", payment: "Completed", documentation: "Complete", weather: "Favorable", market: "Stable", logistics: "On Track", previousDelay: "None", status: "Completed", notes: "Acquisition closed.", month: 1 },
  { landId: "LA007", farmerName: "Lakshmi", location: "Dindigul", area: 2.2, crop: "Flowers", cost: 880000, ownership: "Clear", payment: "Partial", documentation: "Complete", weather: "Unfavorable", market: "Rising", logistics: "On Track", previousDelay: "Occasional", status: "In Progress", notes: "Balance payment planned after field verification.", month: 4 },
  { landId: "LA008", farmerName: "Muthu", location: "Virudhunagar", area: 7.7, crop: "Millets", cost: 2920000, ownership: "Disputed", payment: "Pending", documentation: "Incomplete", weather: "Severe", market: "Volatile", logistics: "Blocked", previousDelay: "Frequent", status: "On Hold", notes: "Multiple blockers require escalation.", month: 5 }
];

const weights = {
  ownership: { "Clear": 3, "Pending Verification": 14, "Disputed": 18 },
  payment: { "Completed": 2, "Partial": 14, "Pending": 22 },
  documentation: { "Complete": 2, "Under Review": 10, "Incomplete": 18 },
  weather: { "Favorable": 0, "Normal": 2, "Unfavorable": 8, "Severe": 12 },
  market: { "Stable": 1, "Rising": 4, "Volatile": 8 },
  logistics: { "On Track": 1, "At Risk": 7, "Blocked": 10 },
  previousDelay: { "None": 0, "Occasional": 6, "Frequent": 9 },
  status: { "Completed": 0, "In Progress": 0, "Pending": 0, "On Hold": 1 }
};

const reasonLabels = {
  ownership: "Ownership Dispute",
  payment: "Payment Pending",
  documentation: "Documentation Issue",
  weather: "Weather Disruption",
  market: "Market Volatility",
  logistics: "Logistics Problem",
  previousDelay: "Previous Delay History"
};

const actionLabels = {
  ownership: "Resolve ownership dispute",
  payment: "Complete pending payment",
  documentation: "Verify pending documents",
  weather: "Monitor weather conditions",
  market: "Review market movement",
  logistics: "Solve logistics problem",
  previousDelay: "Contact farmer and prioritize case"
};

const factorLabels = {
  ownership: "Ownership",
  payment: "Payment",
  documentation: "Documents",
  weather: "Weather",
  market: "Market",
  logistics: "Logistics",
  previousDelay: "History",
  status: "Status"
};

let parcels = loadParcels();
let currentRoute = getRoute();
let toastTimer;

function loadParcels() {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (Array.isArray(stored) && stored.length) return stored;
  } catch (error) { /* fall back to seed data */ }
  return structuredClone(seedParcels);
}

function persist() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(parcels));
  document.getElementById("lastUpdated").textContent = "just now";
}

function getRisk(record) {
  const contributions = Object.entries(weights).map(([key, map]) => ({ key, score: map[record[key]] || 0 }));
  const raw = contributions.reduce((sum, item) => sum + item.score, 0);
  const score = Math.min(100, Math.max(0, raw));
  const level = score >= 70 ? "high" : score >= 40 ? "medium" : "low";
  const top = [...contributions].sort((a, b) => b.score - a.score)[0];
  const reason = level === "low" ? "Minor Processing Delay" : (top && top.score ? reasonLabels[top.key] : "Minor Processing Delay");
  const action = level === "low" ? "Continue regular monitoring" : (top && top.score ? actionLabels[top.key] : "Continue regular monitoring");
  let delay = "0–10 days";
  if (level === "medium") delay = "15–25 days";
  if (level === "high") delay = "30–45 days";
  const warning = level === "high" ? "HIGH DELAY RISK – Immediate action is required." : level === "medium" ? "MEDIUM DELAY RISK – Close monitoring is required." : "LOW DELAY RISK – Continue regular monitoring.";
  const explanation = contributions.filter(item => item.score > 0).sort((a, b) => b.score - a.score).map(item => `${factorLabels[item.key]} +${item.score}`).join(" · ") || "No material risk signals";
  return { score, level, reason, action, delay, warning, contributions, explanation };
}

function derivedRecords() { return parcels.map(parcel => ({ ...parcel, risk: getRisk(parcel) })); }
function getRoute() {
  const hash = window.location.hash.replace("#", "").toLowerCase();
  const pathname = window.location.pathname.replace(/^\//, "").toLowerCase();
  const route = hash || pathname;
  return ["registry", "reports"].includes(route) ? route : "overview";
}
function formatMoney(value) { return value ? `₹${Number(value).toLocaleString("en-IN")}` : "—"; }
function escapeHtml(value) { return String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[char])); }
function plural(number, singular, pluralForm = `${singular}s`) { return `${number} ${number === 1 ? singular : pluralForm}`; }

function renderAll() {
  const records = derivedRecords();
  renderRoute();
  renderMetrics(records);
  renderWarnings(records);
  renderDistribution(records);
  renderReasons(records);
  renderLocations(records);
  renderTable(records);
  renderReports(records);
  updatePreview();
  document.getElementById("notificationBadge").style.display = records.some(item => item.risk.level === "high") ? "block" : "none";
  document.getElementById("notificationBadge").textContent = records.filter(item => item.risk.level === "high").length;
}

function renderRoute() {
  document.querySelectorAll(".page-section").forEach(section => section.classList.toggle("active", section.dataset.section === currentRoute));
  document.querySelectorAll(".nav-item").forEach(item => item.classList.toggle("active", item.dataset.route === currentRoute));
  const pageTitle = currentRoute === "registry" ? "Land registry" : currentRoute === "reports" ? "Reports" : "Overview";
  document.getElementById("pageTitle").textContent = pageTitle;
}

function renderMetrics(records) {
  const total = records.length;
  const completed = records.filter(r => r.status === "Completed").length;
  const pending = total - completed;
  const low = records.filter(r => r.risk.level === "low").length;
  const medium = records.filter(r => r.risk.level === "medium").length;
  const high = records.filter(r => r.risk.level === "high").length;
  const delayPercentage = total ? Math.round((records.filter(r => r.risk.score >= 40).length / total) * 100) : 0;
  const metrics = [
    ["Total land parcels", total, "Across active districts", "◫", ""],
    ["Completed acquisitions", completed, `${total ? Math.round(completed / total * 100) : 0}% of total portfolio`, "✓", ""],
    ["Pending acquisitions", pending, "Need ongoing action", "◌", "warning"],
    ["Overall delay percentage", `${delayPercentage}%`, "Medium + high risk cases", "↗", delayPercentage > 50 ? "danger" : "neutral"],
    ["Low risk cases", low, "0–39 score band", "L", ""],
    ["Medium risk cases", medium, "40–69 score band", "M", "warning"],
    ["High risk cases", high, "70–100 score band", "H", "danger"],
    ["Avg. risk score", total ? Math.round(records.reduce((sum, r) => sum + r.risk.score, 0) / total) : 0, "Across all parcels", "∿", "neutral"]
  ];
  document.getElementById("metricGrid").innerHTML = metrics.map(([label, value, foot, symbol, tone]) => `<div class="metric-card ${tone}"><div class="metric-top"><span>${label}</span><span class="metric-symbol">${symbol}</span></div><strong class="metric-value">${value}</strong><div class="metric-foot">${foot}</div></div>`).join("");
}

function renderWarnings(records) {
  const target = document.getElementById("warningList");
  const prioritized = [...records].sort((a, b) => b.risk.score - a.risk.score).slice(0, 4);
  target.innerHTML = prioritized.length ? prioritized.map(record => `<div class="warning-item ${record.risk.level}"><div class="warning-main"><span class="warning-marker"></span><div><div class="warning-title">${escapeHtml(record.landId)} · ${escapeHtml(record.farmerName)} <span class="risk-badge ${record.risk.level}">${record.risk.level.toUpperCase()} RISK</span></div><div class="warning-copy">${record.risk.warning} ${escapeHtml(record.risk.action)}.</div></div></div><div class="warning-meta"><div class="warning-risk ${record.risk.level}">${record.risk.score}</div><div class="warning-action">${escapeHtml(record.risk.delay)}</div></div></div>`).join("") : `<div class="table-empty"><h3>No parcel signals yet</h3><p>Add a parcel to activate the warning system.</p></div>`;
}

function renderDistribution(records) {
  const counts = { high: records.filter(r => r.risk.level === "high").length, medium: records.filter(r => r.risk.level === "medium").length, low: records.filter(r => r.risk.level === "low").length };
  const total = records.length || 1;
  const highPct = counts.high / total * 100;
  const mediumPct = counts.medium / total * 100;
  ["riskDonut", "reportRiskDonut"].forEach(id => { const el = document.getElementById(id); if (el) { el.style.setProperty("--high", `${highPct}%`); el.style.setProperty("--medium", `${mediumPct}%`); } });
  const avg = records.length ? Math.round(records.reduce((sum, r) => sum + r.risk.score, 0) / records.length) : 0;
  document.getElementById("riskAverage").textContent = avg;
  document.getElementById("reportRiskAvg").textContent = avg;
  const legend = `<div class="legend-row"><i style="background:var(--coral)"></i><span>High risk</span><strong>${counts.high}</strong></div><div class="legend-row"><i style="background:var(--amber)"></i><span>Medium risk</span><strong>${counts.medium}</strong></div><div class="legend-row"><i style="background:var(--teal)"></i><span>Low risk</span><strong>${counts.low}</strong></div>`;
  document.getElementById("riskLegend").innerHTML = legend;
  document.getElementById("reportRiskLegend").innerHTML = legend;
  document.getElementById("highRiskFoot").textContent = counts.high;
}

function aggregateReasons(records) {
  const map = {};
  records.forEach(record => { map[record.risk.reason] = (map[record.risk.reason] || 0) + 1; });
  return Object.entries(map).sort((a, b) => b[1] - a[1]);
}
function renderReasons(records) {
  const data = aggregateReasons(records);
  const max = data[0]?.[1] || 1;
  const bars = data.slice(0, 5).map(([label, count], index) => `<div class="bar-row"><span class="bar-label">${escapeHtml(label)}</span><span class="bar-track"><span class="bar-fill ${index === 0 ? "coral" : index === 1 ? "amber" : ""}" style="width:${count / max * 100}%"></span></span><span class="bar-value">${count}</span></div>`).join("");
  document.getElementById("reasonBars").innerHTML = bars || `<p class="heading-meta">No delay reasons yet.</p>`;
}
function locationData(records) {
  const groups = {};
  records.forEach(record => { if (!groups[record.location]) groups[record.location] = { count: 0, total: 0, high: 0 }; groups[record.location].count++; groups[record.location].total += record.risk.score; if (record.risk.level === "high") groups[record.location].high++; });
  return Object.entries(groups).map(([name, data]) => ({ name, count: data.count, score: Math.round(data.total / data.count), high: data.high })).sort((a, b) => b.score - a.score);
}
function renderLocations(records) {
  const data = locationData(records);
  document.getElementById("locationList").innerHTML = data.slice(0, 5).map(item => `<div class="location-row"><div><div class="location-name">${escapeHtml(item.name)} <span class="location-count">· ${item.count}</span></div><div class="location-bar"><span style="width:${item.score}%"></span></div></div><span class="location-count">${item.high} high</span><span class="location-score">${item.score}</span></div>`).join("") || `<p class="heading-meta">No locations yet.</p>`;
}

function getFilteredRecords(records) {
  const query = document.getElementById("searchInput").value.trim().toLowerCase();
  const risk = document.getElementById("riskFilter").value;
  const status = document.getElementById("statusFilter").value;
  return records.filter(record => {
    const matchesQuery = !query || [record.landId, record.farmerName, record.location, record.crop, record.risk.reason].some(value => String(value).toLowerCase().includes(query));
    const matchesRisk = risk === "all" || record.risk.level === risk;
    const matchesStatus = status === "all" || record.status === status;
    return matchesQuery && matchesRisk && matchesStatus;
  });
}
function renderTable(records) {
  const filtered = getFilteredRecords(records);
  document.getElementById("registrySummary").textContent = `${plural(filtered.length, "parcel")} in view`;
  document.getElementById("tableEmpty").hidden = Boolean(filtered.length);
  document.getElementById("parcelTableBody").innerHTML = filtered.map(record => `<tr><td><div class="parcel-cell"><div class="parcel-avatar">${escapeHtml(record.landId.slice(-2))}</div><div><div class="parcel-id">${escapeHtml(record.landId)}</div><div class="parcel-farmer">${escapeHtml(record.farmerName)} · ${escapeHtml(record.crop || "Mixed crop")}</div></div></div></td><td>${escapeHtml(record.location)}</td><td>${record.area} ac</td><td><span class="score-cell ${record.risk.level}">${record.risk.score}</span> <span class="risk-badge ${record.risk.level}">${record.risk.level}</span></td><td class="table-reason">${escapeHtml(record.risk.reason)}</td><td>${record.risk.delay}</td><td class="table-action">${escapeHtml(record.risk.action)}</td><td><span class="status-pill ${record.status.toLowerCase().replaceAll(" ", "-")}">${escapeHtml(record.status)}</span></td><td><div class="row-actions"><button class="row-action" data-edit="${escapeHtml(record.landId)}" title="Edit parcel">✎</button><button class="row-action delete" data-delete="${escapeHtml(record.landId)}" title="Delete parcel">×</button></div></td></tr>`).join("");
}

function renderReports(records) {
  const payments = ["Completed", "Partial", "Pending"].map(status => [status, records.filter(r => r.payment === status).length]);
  const maxPayment = Math.max(1, ...payments.map(item => item[1]));
  document.getElementById("paymentBars").innerHTML = payments.map(([label, count], index) => `<div class="horizontal-bar-row"><span>${label}</span><span class="bar-track"><span class="bar-fill ${index === 2 ? "coral" : index === 1 ? "amber" : ""}" style="width:${count / maxPayment * 100}%"></span></span><span class="bar-value">${count} parcels</span></div>`).join("");
  const statuses = [["Completed", "completed"], ["In Progress", ""], ["Pending", "pending"], ["On Hold", "hold"]];
  document.getElementById("progressReport").innerHTML = statuses.map(([label, cls]) => `<div class="progress-card ${cls}"><strong>${records.filter(r => r.status === label).length}</strong><span>${label}</span><small>${records.length ? Math.round(records.filter(r => r.status === label).length / records.length * 100) : 0}% of parcels</small></div>`).join("");
  const locations = locationData(records);
  document.getElementById("locationReport").innerHTML = locations.map(item => `<div class="location-row"><div class="location-name">${escapeHtml(item.name)} <span class="location-count">· ${item.count} parcels</span></div><div class="location-bar"><span style="width:${item.score}%"></span></div><span class="location-score">${item.score}</span></div>`).join("") || `<p class="heading-meta">No location data yet.</p>`;
  const reasons = aggregateReasons(records);
  const maxReason = Math.max(1, ...reasons.map(item => item[1]));
  document.getElementById("reasonReport").innerHTML = reasons.map(([label, count], index) => `<div class="bar-row"><span class="bar-label">${escapeHtml(label)}</span><span class="bar-track"><span class="bar-fill ${index === 0 ? "coral" : index === 1 ? "amber" : ""}" style="width:${count / maxReason * 100}%"></span></span><span class="bar-value">${count}</span></div>`).join("") || `<p class="heading-meta">No reasons yet.</p>`;
  renderTrend(records);
}
function renderTrend(records) {
  const months = ["May", "Jun", "Jul", "Aug", "Sep", "Oct"];
  const values = months.map((_, index) => records.filter(record => record.month === index).length + (index === 5 ? records.filter(record => record.risk.level === "high").length : 0));
  const max = Math.max(4, ...values);
  const width = 700, height = 168, padX = 24, padY = 24;
  const points = values.map((value, index) => `${padX + index * ((width - padX * 2) / (values.length - 1))},${height - padY - value / max * (height - padY * 2)}`).join(" ");
  const dots = values.map((value, index) => { const x = padX + index * ((width - padX * 2) / (values.length - 1)); const y = height - padY - value / max * (height - padY * 2); return `<circle cx="${x}" cy="${y}" r="4" fill="white" stroke="var(--teal)" stroke-width="3"></circle><text x="${x}" y="${y - 10}" text-anchor="middle" class="trend-value">${value}</text><text x="${x}" y="${height + 1}" text-anchor="middle" class="trend-label">${months[index]}</text>`; }).join("");
  const lines = [0, .5, 1].map(ratio => { const y = height - padY - ratio * (height - padY * 2); return `<line x1="${padX}" x2="${width - padX}" y1="${y}" y2="${y}" stroke="#e8efed" stroke-width="1"></line>`; }).join("");
  document.getElementById("trendChart").innerHTML = `<svg class="trend-svg" viewBox="0 0 ${width} ${height + 14}" preserveAspectRatio="none">${lines}<polyline points="${points}" fill="none" stroke="var(--teal)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></polyline>${dots}</svg>`;
}

function openModal(id = null) {
  const modal = document.getElementById("parcelModal");
  const form = document.getElementById("parcelForm");
  form.reset();
  document.getElementById("editId").value = "";
  document.getElementById("modalTitle").textContent = id ? "Edit land parcel" : "Add land parcel";
  if (id) {
    const record = parcels.find(parcel => parcel.landId === id);
    if (record) Object.entries(record).forEach(([key, value]) => { const field = document.getElementById(key); if (field) field.value = value ?? ""; });
    document.getElementById("editId").value = id;
  }
  modal.hidden = false;
  document.body.style.overflow = "hidden";
  updatePreview();
  setTimeout(() => document.getElementById("landId").focus(), 50);
}
function closeModal() { document.getElementById("parcelModal").hidden = true; document.body.style.overflow = ""; }
function formRecord() {
  const form = document.getElementById("parcelForm");
  const data = Object.fromEntries(new FormData(form).entries());
  return { ...data, area: Number(data.area || 0), cost: Number(data.cost || 0), month: new Date().getMonth() };
}
function updatePreview() {
  const data = formRecord();
  const risk = getRisk(data);
  document.getElementById("previewScore").textContent = risk.score;
  const badge = document.getElementById("previewRisk");
  badge.className = `risk-badge ${risk.level}`;
  badge.textContent = `${risk.level.toUpperCase()} RISK`;
  document.getElementById("previewReason").textContent = risk.reason;
  document.getElementById("previewFactors").textContent = risk.explanation;
}
function saveParcel(event) {
  event.preventDefault();
  const record = formRecord();
  const editId = document.getElementById("editId").value;
  if (editId) { parcels = parcels.map(parcel => parcel.landId === editId ? record : parcel); showToast("Parcel updated and model recalculated"); }
  else { if (parcels.some(parcel => parcel.landId.toLowerCase() === record.landId.toLowerCase())) { showToast("Land ID already exists"); return; } parcels = [record, ...parcels]; showToast("New parcel added to the model"); }
  persist(); closeModal(); renderAll();
}
function deleteParcel(id) { const record = parcels.find(parcel => parcel.landId === id); if (!record) return; parcels = parcels.filter(parcel => parcel.landId !== id); persist(); renderAll(); showToast(`${id} removed from the registry`); }
function showToast(message) { const toast = document.getElementById("toast"); document.getElementById("toastMessage").textContent = message; toast.classList.add("show"); clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove("show"), 2800); }
function exportSummary() { const rows = derivedRecords().map(record => [record.landId, record.farmerName, record.location, record.risk.score, record.risk.level, record.risk.reason, record.risk.delay, record.status].join(",")); const csv = ["Land ID,Farmer,Location,Risk Score,Risk Level,Main Reason,Expected Delay,Status", ...rows].join("\n"); const blob = new Blob([csv], { type: "text/csv" }); const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = "landrisk-summary.csv"; link.click(); URL.revokeObjectURL(url); showToast("Summary exported as CSV"); }

function bindEvents() {
  window.addEventListener("hashchange", () => { currentRoute = getRoute(); renderAll(); });
  document.getElementById("addParcelBtn").addEventListener("click", () => openModal());
  document.getElementById("addParcelBtnRegistry").addEventListener("click", () => openModal());
  document.getElementById("closeModalBtn").addEventListener("click", closeModal);
  document.getElementById("cancelModalBtn").addEventListener("click", closeModal);
  document.getElementById("parcelModal").addEventListener("click", event => { if (event.target.id === "parcelModal") closeModal(); });
  document.getElementById("parcelForm").addEventListener("submit", saveParcel);
  ["landId", "farmerName", "location", "area", "crop", "cost", "ownership", "payment", "documentation", "weather", "market", "logistics", "previousDelay", "status"].forEach(id => document.getElementById(id).addEventListener("input", updatePreview));
  ["searchInput", "riskFilter", "statusFilter"].forEach(id => document.getElementById(id).addEventListener("input", () => renderTable(derivedRecords())));
  document.getElementById("parcelTableBody").addEventListener("click", event => { const edit = event.target.closest("[data-edit]"); const del = event.target.closest("[data-delete]"); if (edit) openModal(edit.dataset.edit); if (del) deleteParcel(del.dataset.delete); });
  document.querySelectorAll("[data-go]").forEach(button => button.addEventListener("click", () => { window.location.hash = button.dataset.go; }));
  document.getElementById("resetDataBtn").addEventListener("click", () => { parcels = structuredClone(seedParcels); persist(); renderAll(); showToast("Demo data restored"); });
  document.getElementById("exportBtn").addEventListener("click", exportSummary);
  document.getElementById("notificationBtn").addEventListener("click", () => { window.location.hash = "registry"; document.getElementById("riskFilter").value = "high"; renderTable(derivedRecords()); });
  document.getElementById("mobileMenuBtn").addEventListener("click", () => document.getElementById("sidebar").classList.toggle("open"));
  document.querySelectorAll(".nav-item").forEach(item => item.addEventListener("click", () => document.getElementById("sidebar").classList.remove("open")));
  document.addEventListener("keydown", event => { if (event.key === "Escape" && !document.getElementById("parcelModal").hidden) closeModal(); });
}

bindEvents();
renderAll();
